# TP1
Hay que modificar el Make, yo no lo toqué (compilé a mano para hacer la prueba sobre el test del archivo calculadora.cpp). Todavía no hay modificaciones en las otras clases
